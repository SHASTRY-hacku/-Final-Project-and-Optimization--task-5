// Mobile nav toggle
const menuBtn = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');
if (menuBtn && navLinks) {
  menuBtn.addEventListener('click', () => navLinks.classList.toggle('open'));
}
// Active nav link
const page = document.body.dataset.page;
document.querySelectorAll('.nav-links a').forEach(a => {
  if (a.getAttribute('href').includes(page)) a.setAttribute('aria-current','page');
});
// Contact form validation
const form = document.querySelector('form[data-contact]');
if(form){
  form.addEventListener('submit', e => {
    const name=form.querySelector('[name="name"]');
    const email=form.querySelector('[name="email"]');
    const msg=form.querySelector('[name="message"]');
    const emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let ok=true;
    if(!name.value.trim()){ alert("Please enter your name"); ok=false; }
    else if(!emailPattern.test(email.value.trim())){ alert("Enter valid email"); ok=false; }
    else if(!msg.value.trim()){ alert("Please enter message"); ok=false; }
    if(!ok) e.preventDefault();
  });
}

li.innerHTML = `
  <span>${task.text}</span>
  <div class="actions">
    <button class="btn btn-3d btn-complete ${task.completed ? 'primary' : ''}">
      ${task.completed ? "Undo" : "Done"}
    </button>
    <button class="btn btn-3d btn-delete">Delete</button>
  </div>
`;

